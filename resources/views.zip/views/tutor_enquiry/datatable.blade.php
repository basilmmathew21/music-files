

    <div class="btn-group btn-group-xs pull-right" role="group">
        <a href=" {{ route('tutorenquiries.tutorenquiry.show', $tutor->id) }} " class="btn btn-info" title=" {{ trans('users.show_enquiry') }}">
            <i class="fas fa-eye"></i>
        </a>
      
        
    </div>

