<!DOCTYPE html>
<html>
<head>
    <title>music-shiksha</title>
</head>
<body>
    <h1>{{ $details['subject'] }}</h1>
    <p>{{ $details['content'] }}</p>
    <p>{{ $details['login'] }}</p>
    <p>Thank you</p>
</body>
</html>