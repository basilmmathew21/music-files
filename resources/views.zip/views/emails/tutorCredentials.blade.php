<!DOCTYPE html>
<html>
<head>
    <title>Music-Shiksha</title>
</head>
<body>
<h1>Login Credentials</h1>
    <p>Username : {{ $details['Username'] }}</p>
    <p>Password :{{ $details['Password'] }}</p>    
   
</body>
</html>